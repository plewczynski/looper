#!/bin/bash
# 


nohup analyze_loops.py -ff CCDs.annotated.chr01.bed -eheat  -o CCDs_chr01_200402.dat &> calc_chr01_200402.log &
nohup analyze_loops.py -ff CCDs.annotated.chr02.bed -eheat  -o CCDs_chr02_200402.dat &> calc_chr02_200402.log &
nohup analyze_loops.py -ff CCDs.annotated.chr03.bed -eheat  -o CCDs_chr03_200402.dat &> calc_chr03_200402.log &
nohup analyze_loops.py -ff CCDs.annotated.chr04.bed -eheat  -o CCDs_chr04_200402.dat &> calc_chr04_200402.log &
nohup analyze_loops.py -ff CCDs.annotated.chr05.bed -eheat  -o CCDs_chr05_200402.dat &> calc_chr05_200402.log &
nohup analyze_loops.py -ff CCDs.annotated.chr06.bed -eheat  -o CCDs_chr06_200402.dat &> calc_chr06_200402.log &
nohup analyze_loops.py -ff CCDs.annotated.chr07.bed -eheat  -o CCDs_chr07_200402.dat &> calc_chr07_200402.log &
nohup analyze_loops.py -ff CCDs.annotated.chr08.bed -eheat  -o CCDs_chr08_200402.dat &> calc_chr08_200402.log &
nohup analyze_loops.py -ff CCDs.annotated.chr09.bed -eheat  -o CCDs_chr09_200402.dat &> calc_chr09_200402.log &
nohup analyze_loops.py -ff CCDs.annotated.chr10.bed -eheat  -o CCDs_chr10_200402.dat &> calc_chr10_200402.log &
nohup analyze_loops.py -ff CCDs.annotated.chr11.bed -eheat  -o CCDs_chr11_200402.dat &> calc_chr11_200402.log &
nohup analyze_loops.py -ff CCDs.annotated.chr12.bed -eheat  -o CCDs_chr12_200402.dat &> calc_chr12_200402.log &
nohup analyze_loops.py -ff CCDs.annotated.chr13.bed -eheat  -o CCDs_chr13_200402.dat &> calc_chr13_200402.log &
nohup analyze_loops.py -ff CCDs.annotated.chr14.bed -eheat  -o CCDs_chr14_200402.dat &> calc_chr14_200402.log &
nohup analyze_loops.py -ff CCDs.annotated.chr15.bed -eheat  -o CCDs_chr15_200402.dat &> calc_chr15_200402.log &
nohup analyze_loops.py -ff CCDs.annotated.chr16.bed -eheat  -o CCDs_chr16_200402.dat &> calc_chr16_200402.log &
nohup analyze_loops.py -ff CCDs.annotated.chr17.bed -eheat  -o CCDs_chr17_200402.dat &> calc_chr17_200402.log &
nohup analyze_loops.py -ff CCDs.annotated.chr18.bed -eheat  -o CCDs_chr18_200402.dat &> calc_chr18_200402.log &
nohup analyze_loops.py -ff CCDs.annotated.chr19.bed -eheat  -o CCDs_chr19_200402.dat &> calc_chr19_200402.log &
nohup analyze_loops.py -ff CCDs.annotated.chr20.bed -eheat  -o CCDs_chr20_200402.dat &> calc_chr20_200402.log &
nohup analyze_loops.py -ff CCDs.annotated.chr21.bed -eheat  -o CCDs_chr21_200402.dat &> calc_chr21_200402.log &
nohup analyze_loops.py -ff CCDs.annotated.chr22.bed -eheat  -o CCDs_chr22_200402.dat &> calc_chr22_200402.log &
nohup analyze_loops.py -ff CCDs.annotated.chrXX.bed -eheat  -o CCDs_chrXX_200402.dat &> calc_chrXX_200402.log &



