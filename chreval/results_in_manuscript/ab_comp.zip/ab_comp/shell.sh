#!/bin/bash
# 


nohup analyze_loops.py -ff compartments.annotated.x_chr01.bed -eheat  -o compartments_chr01_200417.dat &> calc_chr01_200417.log &
nohup analyze_loops.py -ff compartments.annotated.x_chr02.bed -eheat  -o compartments_chr02_200417.dat &> calc_chr02_200417.log &
nohup analyze_loops.py -ff compartments.annotated.x_chr03.bed -eheat  -o compartments_chr03_200417.dat &> calc_chr03_200417.log &
nohup analyze_loops.py -ff compartments.annotated.x_chr04.bed -eheat  -o compartments_chr04_200417.dat &> calc_chr04_200417.log &
nohup analyze_loops.py -ff compartments.annotated.x_chr05.bed -eheat  -o compartments_chr05_200417.dat &> calc_chr05_200417.log &
nohup analyze_loops.py -ff compartments.annotated.x_chr06.bed -eheat  -o compartments_chr06_200417.dat &> calc_chr06_200417.log &
nohup analyze_loops.py -ff compartments.annotated.x_chr07.bed -eheat  -o compartments_chr07_200417.dat &> calc_chr07_200417.log &
nohup analyze_loops.py -ff compartments.annotated.x_chr08.bed -eheat  -o compartments_chr08_200417.dat &> calc_chr08_200417.log &
nohup analyze_loops.py -ff compartments.annotated.x_chr09.bed -eheat  -o compartments_chr09_200417.dat &> calc_chr09_200417.log &
nohup analyze_loops.py -ff compartments.annotated.x_chr10.bed -eheat  -o compartments_chr10_200417.dat &> calc_chr10_200417.log &
nohup analyze_loops.py -ff compartments.annotated.x_chr11.bed -eheat  -o compartments_chr11_200417.dat &> calc_chr11_200417.log &
nohup analyze_loops.py -ff compartments.annotated.x_chr12.bed -eheat  -o compartments_chr12_200417.dat &> calc_chr12_200417.log &
nohup analyze_loops.py -ff compartments.annotated.x_chr13.bed -eheat  -o compartments_chr13_200417.dat &> calc_chr13_200417.log &
nohup analyze_loops.py -ff compartments.annotated.x_chr14.bed -eheat  -o compartments_chr14_200417.dat &> calc_chr14_200417.log &
nohup analyze_loops.py -ff compartments.annotated.x_chr15.bed -eheat  -o compartments_chr15_200417.dat &> calc_chr15_200417.log &
nohup analyze_loops.py -ff compartments.annotated.x_chr16.bed -eheat  -o compartments_chr16_200417.dat &> calc_chr16_200417.log &
nohup analyze_loops.py -ff compartments.annotated.x_chr17.bed -eheat  -o compartments_chr17_200417.dat &> calc_chr17_200417.log &
nohup analyze_loops.py -ff compartments.annotated.x_chr18.bed -eheat  -o compartments_chr18_200417.dat &> calc_chr18_200417.log &
nohup analyze_loops.py -ff compartments.annotated.x_chr19.bed -eheat  -o compartments_chr19_200417.dat &> calc_chr19_200417.log &
nohup analyze_loops.py -ff compartments.annotated.x_chr20.bed -eheat  -o compartments_chr20_200417.dat &> calc_chr20_200417.log &
nohup analyze_loops.py -ff compartments.annotated.x_chr21.bed -eheat  -o compartments_chr21_200417.dat &> calc_chr21_200417.log &
nohup analyze_loops.py -ff compartments.annotated.x_chr22.bed -eheat  -o compartments_chr22_200417.dat &> calc_chr22_200417.log &


